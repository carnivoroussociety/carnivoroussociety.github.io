I've been working on a combination patch with includes multiple patches, with many of my own.

Here is the list of features it has:
Zoinkity's 7MB expansion pak patch and EC player pick-up toggle
SubDrag's expansion pak detection code
Extended random head selection to 8 unique heads per stage
Set E9/FB to toggle between main/alt sky banks
Use 36 to toggle objectives while mission is active
Make company logos skip by default
Change 'show ammo on-screen' option to 'anti-aliasing'
Make command 27 return ZX emu joystick (0x10 = z-trigger 0x0-0xF = direction)
Make setting unknown float to 0 start stage without music
Custom 2B multi-function command (see tutorial)
Make F2 calculate distance for player (used for footsteps)
Store and read 4 unique boolean flags per player save
Easily access current character's structure
Force cinema cameras to use widescreen setting
Subtly randomize guard pain sound pitch
Don't fade guards death while on screen (like Perfect Dark)
Basic framebuffer effects and overlay support
Randomized guard sizes (like Perfect Dark)
Advance control over third person cameras
Dynamic screen space reflection (uses texture ID 02E4)
Random multiplayer respawn locations
Drone gun sound effect on alert (optional - see tutorial)
Display health on screen when collecting armor
Extend maximum length for x music trigger
Added grenade pull sound effect for guards
Emit sound from current guard's position

Check the tutorial patch's for a how to guide for all these features.

If you use this mod, please credit Zoinkity for the expansion pak - thank you!

Changelog:
V49:
* Added Perfect Dark wood/metal bullet hole decals (thanks Wreck)
V48:
* Fix gas sound effect glitch for action FB (thanks Wreck)
V47:
* Fix null crash on loading current guard's position for new sound slot ID
V46:
* Allow guards to be shootable after death animation has finished
V45:
* Added new sound slot ID to emit from current guard's position
* Added Bond gasp sound effect to melee attack block (04B2)
* Added location emit flags to blocks (04B2/04B9/Co-Op AI)
* Decreased guard pain randomized pitch (from -75 to -50 detune)
* Increased volume of grenade pull sound effect
V44:
* Make drone sentry alert sound effect fade out (prevent rare audio glitch)
V43:
* Added grenade pull sound effect for guards
V42:
* Imported fixed built-in block 000D from XBLA
V41:
* Extend maximum length for x music trigger
V40:
* Display health when collecting armor
* Improved drone sentry sound effect block (with example sound effect)
V39:
* Added random respawn locations for multiplayer
* Tweaked decay time and volume of all footsteps
* Added drone sentry sound effect block example
V38:
* Lowered volume and increased rate of footsteps (closer to PD)
V37:
* Added sound to guard reload (04B9)
* Fixed reload animation keyframe glitch
V36:
* Improved melee example action blocks (04A0/04A6/04B9)
* Added new reload animation (check 04A0 for install instructions)
V35:
* Fixed bug where guards set to hidden can still take damage
V34:
* Improved melee example action blocks (04A0/04A2/04A6/04B2/04B4/04B5)
* New running melee attack animation
V33:
* Added basic framebuffer effects support
* Added dynamic reflection texture
* Added advance camera control overrides
* Moved tutorial to separate patch (check tutorial folder)
* Guards are now randomly scaled by 2% (only for NPCs with random heads)
* Added RGBA5551 image converter for overlays
* Improved melee example action blocks (04A2/04AD)
V32:
* Added ability to toggle objectives mid-mission (check tutorial setup)
* Tweaked guard pain sound effect pitch (more subtle)
V31:
* Improved melee example action blocks (04A0/04A2/04A6/04AD/04B2/04B7)
* Guards will stop firing and melee attack if Bond gets close (only if guard has been hit or has melee attacked before)
V30:
* Set anti-aliasing off by default
* Updated no aa hack to invert read option
* Renamed 'Disable AA' option to 'Anti-Aliasing'
V29:
* Improved footsteps distance calculation
* (Optional) Make guards not fade on screen unless FPS is low or guard flags are invincible/friendly fire/no auto aim
* Added pointer address (8070011C) for easy access to current character's structure
* Force cinema cameras to use widescreen setting
* Randomly pitch down guard pain sound effect
V28:
* Improved melee example action blocks
* Added numerous death checks to jump to infinite (lower AI load per tick)
* Camping guards stop aiming at player if haven't been on screen for more than 5 seconds
* Make 04A5 have the possibility of investigating dead bodies (25% RNG)
* Fixed camping block using invalid reaction speed (127 -> 100)
* Add 10 second max limit to guards investigating dead bodies
V27:
* Updated footsteps block to not use sound effect slots
* Tweaked descriptions for tutorial
V26:
* Fixed random head patch (now uses 8 random heads every time)
V25:
* Check if save flags were modified before saving EEPROM during level exit
V24:
* Added EEPROM save flags functionality
V23:
* 2BFD copy: Use lw/sw if source/target/length is 4 byte aligned
V22:
* Apply FOV override to intro camera
V21:
* Fixed corrupted runway setup
* Fixed multiplayer weapon zoom issue
V20:
* Included melee example blocks
* Reorganized all assembly
* Removed 7F00 hack (use EB instead)
V19:
* Added remove item command
* Added new copy length argument for FD
* Updated assembly notes
V18:
* Moved address for camera FOV
* Reset camera FOV on map load
* Reorganized all assembly
V17:
* Moved FD kill player to FC
* Ignore invincibility for FC kill player
* Added new delta time compensation to FE add/sub
* Added new FD copy memory command
* Updated tutorial level with new commands
* Added new camera FOV override for more cinematic control
V16:
* Moved all assembly hacks to 21990 (reduced TLB refills)
* Added 2BFD kill player command
V15:
* Optimized assembly
* Fixed crash if 2B x-track command reached end of table
* Added 2BFE reference manual to bunker i tutorial (check 0408)
* Increased footstep rate to match Perfect Dark
V14:
* Reorganized assembly notes
* Fixed 0xBB000
V13:
* Added float flag for addition/subtraction arguments
* Added interactive conversation tutorial with 27 command
V12:
* Tweaked 2BFE and fixed footsteps block bug (invalid returns)
V11:
* Force AA on when not in-game
V10:
* Added return argument to 2BFE
* Simplified all blocks
* Added portable medkit block (2BFE example - hold B+R to heal)
V9:
* Added F2 init command (required for console compatibility)
* Simplified footsteps block
* Lowered volume for footsteps (matches PD)
* Fixed credits from crashing
* Unlocked all cheats and missions by default
V8:
* Added 2BFE tutorial to bunker i
* Improved footsteps block (now has mid-air detection)
* Fixed bug for FE compare arguments