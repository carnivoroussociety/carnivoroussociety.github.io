Melee Attack Blocks by Carnivorous
A drop in replacement for the built-in blocks

* Features
	Guards reload their weapon after firing multiple times, randomized per guard
	Guards witnessing another guard dying sometimes run over and investigate (like Perfect Dark)
	Guards will wander back to preset location (2328) after chasing and losing Bond
	Guards will randomly melee attack if Bond is within melee attack range
	Guards will stop firing and melee if Bond gets close (only if mask 20 set or guard has been hit)
	Guards will use running melee attack animation if last melee attack did not hit (if within range)
	Guards have a small chance of taunting Bond's death
	Tested on hardware and emulator

* How to Install
	Download and use the footsteps patch ROM as a base (needed for 2B sub-action)
	Import blocks as their filename IDs and set guards to blocks 04A2/04A5/04AD/04B4/04B5
	Import the melee attack animations as ID 81 - or add a new animation as ID B7 and update block 04B2
	Import the reload animation as ID B0 - or add a new animation as ID B8 and update block 04B9
	Set guard's wander location to 2328 preset (object editor) - if set to FFFF guard will not wander
	Check the included patch (melee example.xdelta) for an example working level (bunker i)

* Mask types for guards (can be combined)
	01 - Guard has seen Bond
	02 - Guard does not reload
	04 - Drop primary weapon and swap to DD44 when reloading
	08 - Guard always run to Bond
	10 - Guard chases Bond and melee attack (forever - until mask is unset)
	20 - Guard has executed melee attack at least once (allow melee attacks to interrupt firing)
	40 - Guard last executed melee attack missed (always use running melee attack when in range)
	User byte #1 is used for counting number of times guard fired weapon

* Notes
	User byte #1 should be set to 0 upon jumping to modded blocks
	Remember to set the correct mask type before jumping to new blocks (good default is mask 01 only)
	To use block 04A9 set the guard's 2328 to the alarm/object, will not work for large consoles/props