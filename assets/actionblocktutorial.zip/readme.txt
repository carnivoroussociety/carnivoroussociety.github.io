The following tutorial is to understand
how to use 16 object tags to detect when
the player has 'activated' a object. It
includes 6 different types, ranging from
a simple sound trigger, all the way to a
door opener.

Included is a xdelta patch, and the raw
setup file. Use Xdelta/editor to patch the
rom and player Bunker 1 to test. Comments
for each block can be found in the blocks
themselves as a debug comment (AD).