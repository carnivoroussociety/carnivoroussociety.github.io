==GoldenEye 007 - N64 Mouse Patch==

About this Patch
	This patch will enable GoldenEye 007 to use mouse look using the N64 mouse.
	Start the game and connect the N64 mouse into player 2 port.
	In-game controls are hardcoded to use 1.2 scheme - use C buttons to move and analog stick down to crouch.

How to Install
	Use your preferred xdelta/IPS program to apply the patch against a NTSC-U GoldenEye 007 ROM.
	If you are not sure which patch to use, I recommend using patch 'GoldenEye 007 - N64 Mouse V1 (Unlocked Profile).xdelta'.
	If you don't have the xdelta program, you can use the site https://hack64.net/tools/patcher.php

Notes
	The IPS patches are there for those who want to apply the N64 mouse patch to custom levels.
	Menus require controller 1 to use. Multiplayer is not available with this patch.

Special Thanks To
	YouTube.com/Graslu00 - Testing and providing feedback
	Zoinkity - Documentation and notes

Version history
	1.1 - Added right click to B button version
	1.0 - First Version

Disclaimer
	By using this patch you confirm that you will not sell or make any profit on the patch or resulting modified ROM.
	You also agree that the ROM will not be included in any emulator builds or assembled ROM sets.