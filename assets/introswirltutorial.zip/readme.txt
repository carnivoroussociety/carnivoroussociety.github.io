This is an example of the newly added intro spline animation import feature for GE. Inside is the setup with the imported spline, and the animation file itself.

To import the animation, open the intro block dialog and go to command 03, then click import animation. Select the FBX file and the editor will do the rest.

To create new splines, I suggest importing a swirl.txt file from another level, then exporting it as a animation. Unit coordinates are 1:1 with the level scale and should work in match up 3D editor of choice. Create your camera path and export as a FBX file, then import using the above method.

Important: You must have the FBX build of obj2an8 for the spline to import. You can download it by following the Setup Editor's GitHub readme.